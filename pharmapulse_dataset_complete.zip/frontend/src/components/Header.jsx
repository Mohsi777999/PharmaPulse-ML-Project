import React from 'react';
import { Server, Activity, Database, RefreshCw } from 'lucide-react';

export default function Header({ activeView, onRefresh, loading }) {
  const titles = {
    overview: 'Operations Overview & Intelligence Portal',
    forecasting: 'Module 1 • Demand Forecasting Engine',
    expiry: 'Module 2 • Batch Expiry Risk & Capital Exposure',
    stockout: 'Module 3 • Stockout & Replenishment Pipeline Risk',
    clustering: 'Module 4 • Medicine Sales Behaviour Clustering',
    performance: 'Machine Learning Algorithm Performance & Benchmarks',
    reports: 'Audit-Ready Operational Reports & Data Export'
  };

  return (
    <header style={{
      height: '64px',
      backgroundColor: 'var(--bg-canvas)',
      borderBottom: '1px solid var(--border-subtle)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 28px',
      position: 'sticky',
      top: 0,
      zIndex: 10
    }}>
      <div>
        <h2 style={{ fontSize: '1.05rem', fontWeight: 700, color: '#F8FAFC' }}>
          {titles[activeView] || 'Intelligence Portal'}
        </h2>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
        {/* Backend Status Indicator */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '7px',
          background: 'rgba(56, 189, 248, 0.08)',
          border: '1px solid rgba(56, 189, 248, 0.25)',
          padding: '4px 10px',
          borderRadius: '20px',
          fontSize: '0.74rem',
          color: '#38BDF8',
          fontWeight: 600
        }}>
          <Server size={13} />
          <span>FastAPI Online • Port 8000</span>
        </div>

        {/* Currency Pill */}
        <div style={{
          background: 'rgba(255, 255, 255, 0.05)',
          border: '1px solid var(--border-subtle)',
          padding: '4px 10px',
          borderRadius: '6px',
          fontSize: '0.74rem',
          color: '#94A3B8',
          fontWeight: 600
        }}>
          PKR (Rs.)
        </div>

        {/* Refresh Button */}
        {onRefresh && (
          <button
            onClick={onRefresh}
            disabled={loading}
            style={{
              background: 'transparent',
              border: '1px solid var(--border-subtle)',
              borderRadius: '6px',
              color: '#94A3B8',
              padding: '6px 10px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              fontSize: '0.74rem'
            }}
          >
            <RefreshCw size={13} className={loading ? 'animate-spin' : ''} />
            <span>Sync</span>
          </button>
        )}
      </div>
    </header>
  );
}
