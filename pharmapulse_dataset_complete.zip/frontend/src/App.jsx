import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import OverviewView from './views/OverviewView';
import ForecastingView from './views/ForecastingView';
import ExpiryView from './views/ExpiryView';
import StockoutView from './views/StockoutView';
import ClusteringView from './views/ClusteringView';
import PerformanceView from './views/PerformanceView';
import ReportsView from './views/ReportsView';
import { api } from './services/api';

export default function App() {
  const [activeView, setActiveView] = useState('overview');
  const [systemStatus, setSystemStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    checkHealth();
  }, []);

  const checkHealth = async () => {
    try {
      setLoading(true);
      const res = await api.getHealth();
      setSystemStatus(res);
    } catch (err) {
      console.error('Backend offline or unreachable:', err);
    } finally {
      setLoading(false);
    }
  };

  const renderActiveView = () => {
    switch (activeView) {
      case 'overview':
        return <OverviewView />;
      case 'forecasting':
        return <ForecastingView />;
      case 'expiry':
        return <ExpiryView />;
      case 'stockout':
        return <StockoutView />;
      case 'clustering':
        return <ClusteringView />;
      case 'performance':
        return <PerformanceView />;
      case 'reports':
        return <ReportsView />;
      default:
        return <OverviewView />;
    }
  };

  return (
    <div style={{ display: 'flex', minHeight: '100vh', backgroundColor: 'var(--bg-canvas)' }}>
      {/* Sidebar Navigation */}
      <Sidebar
        activeView={activeView}
        setActiveView={setActiveView}
        systemStatus={systemStatus}
      />

      {/* Main Content Area */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <Header
          activeView={activeView}
          onRefresh={checkHealth}
          loading={loading}
        />

        <main style={{ flex: 1, padding: '24px 28px', maxWidth: '1440px', width: '100%', margin: '0 auto' }}>
          {renderActiveView()}
        </main>
      </div>
    </div>
  );
}
