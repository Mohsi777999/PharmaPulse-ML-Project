import React, { useState, useEffect } from 'react';
import HeroBanner from '../components/HeroBanner';
import { api } from '../services/api';
import { FileText, Download, CheckCircle, Table, Eye } from 'lucide-react';

export default function ReportsView() {
  const [reportsList, setReportsList] = useState([]);
  const [selectedReportId, setSelectedReportId] = useState('demand_forecasting');
  const [reportData, setReportData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getReportsList().then((res) => {
      setReportsList(res);
      if (res.length > 0) {
        setSelectedReportId(res[0].id);
      }
    }).catch(console.error);
  }, []);

  useEffect(() => {
    if (selectedReportId) {
      loadReportDetails();
    }
  }, [selectedReportId]);

  const loadReportDetails = async () => {
    try {
      setLoading(true);
      const res = await api.getReport(selectedReportId);
      setReportData(res);
    } catch (err) {
      console.error('Failed to load report:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadCsv = () => {
    const url = api.getReportCsvUrl(selectedReportId);
    window.open(url, '_blank');
  };

  const activeReportMeta = reportsList.find((r) => r.id === selectedReportId);

  return (
    <div>
      <HeroBanner
        tag="EXECUTIVE AUDIT & DATA EXPORT"
        title="Audit-Ready Intelligence Reports & Data Exports"
        subtitle="Automated generation of formal operational audits, financial risk registers, and algorithm benchmarking scorecards."
      />

      {/* Report Selection Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '14px', marginBottom: '24px' }}>
        {reportsList.map((rep) => {
          const isSelected = rep.id === selectedReportId;
          return (
            <div
              key={rep.id}
              onClick={() => setSelectedReportId(rep.id)}
              className="glass-panel"
              style={{
                padding: '16px',
                cursor: 'pointer',
                border: isSelected ? '1px solid #38BDF8' : '1px solid var(--border-subtle)',
                background: isSelected ? 'linear-gradient(135deg, rgba(14, 165, 233, 0.12) 0%, rgba(17, 24, 39, 0.8) 100%)' : 'var(--bg-surface)',
                transition: 'all 0.15s ease'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <FileText size={16} color={isSelected ? '#38BDF8' : '#64748B'} />
                  <div style={{ fontSize: '0.86rem', fontWeight: 700, color: isSelected ? '#38BDF8' : '#F1F5F9' }}>
                    {rep.name}
                  </div>
                </div>
                {isSelected && <CheckCircle size={14} color="#38BDF8" />}
              </div>
              <div style={{ fontSize: '0.74rem', color: '#94A3B8', lineHeight: '1.4' }}>
                {rep.description}
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Report Preview & Download Action Bar */}
      {reportData && (
        <div className="glass-panel" style={{ padding: '22px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '18px' }}>
            <div>
              <div style={{ fontSize: '1.05rem', fontWeight: 800, color: '#F8FAFC' }}>
                {activeReportMeta?.name}
              </div>
              <div style={{ fontSize: '0.76rem', color: '#94A3B8' }}>
                Displaying first {reportData.preview?.length || 0} records of {reportData.total_records?.toLocaleString() || 0} total rows
              </div>
            </div>

            <button
              onClick={handleDownloadCsv}
              className="btn-primary"
              style={{ padding: '9px 18px', fontSize: '0.84rem' }}
            >
              <Download size={15} />
              <span>Export CSV Document</span>
            </button>
          </div>

          {loading ? (
            <div style={{ padding: '30px', textAlign: 'center', color: '#94A3B8' }}>
              <div className="pulse-dot" style={{ width: '10px', height: '10px', marginBottom: '8px' }}></div>
              <div>Compiling audit report records...</div>
            </div>
          ) : (
            <div className="data-table-container">
              <table className="data-table">
                <thead>
                  <tr>
                    {reportData.columns && reportData.columns.map((col, idx) => (
                      <th key={idx}>{col.replace(/_/g, ' ').toUpperCase()}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {reportData.preview && reportData.preview.map((row, rIdx) => (
                    <tr key={rIdx}>
                      {reportData.columns.map((col, cIdx) => (
                        <td key={cIdx}>
                          {typeof row[col] === 'number'
                            ? Number(row[col]).toLocaleString()
                            : String(row[col] ?? '')}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
