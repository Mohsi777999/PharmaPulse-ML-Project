import React, { useState, useEffect } from 'react';
import HeroBanner from '../components/HeroBanner';
import { api } from '../services/api';
import { Microscope, Award, CheckCircle2, TrendingUp, AlertTriangle, ShieldCheck, PieChart } from 'lucide-react';

export default function PerformanceView() {
  const [data, setData] = useState(null);
  const [activeTab, setActiveTab] = useState('forecasting');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPerformance();
  }, []);

  const loadPerformance = async () => {
    try {
      setLoading(true);
      const res = await api.getPerformance();
      setData(res);
    } catch (err) {
      console.error('Failed to load performance data:', err);
    } finally {
      setLoading(false);
    }
  };

  const tabs = [
    { id: 'forecasting', label: '1. Demand Forecasting', icon: TrendingUp },
    { id: 'expiry', label: '2. Expiry Risk (Dual-Task)', icon: AlertTriangle },
    { id: 'stockout', label: '3. Stockout Prediction', icon: ShieldCheck },
    { id: 'clustering', label: '4. Sales Clustering', icon: PieChart },
  ];

  return (
    <div>
      <HeroBanner
        tag="ALGORITHM EVALUATION & VALIDATION BENCHMARKS"
        title="Machine Learning Algorithm Performance & Benchmarks"
        subtitle="Comparative empirical evaluation metrics, confusion matrices, and validation scorecards across candidate models evaluated on out-of-sample holdout test partitions."
      />

      {/* Tab Navigation Strip */}
      <div style={{ display: 'flex', gap: '8px', borderBottom: '1px solid var(--border-subtle)', marginBottom: '22px' }}>
        {tabs.map((t) => {
          const Icon = t.icon;
          const isActive = activeTab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                padding: '12px 18px',
                background: 'transparent',
                border: 'none',
                borderBottom: isActive ? '2px solid #38BDF8' : '2px solid transparent',
                color: isActive ? '#38BDF8' : '#94A3B8',
                fontWeight: isActive ? 700 : 500,
                fontSize: '0.86rem',
                cursor: 'pointer',
                transition: 'all 0.15s ease'
              }}
            >
              <Icon size={16} />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {loading && !data ? (
        <div style={{ padding: '40px', textAlign: 'center', color: '#94A3B8' }}>
          <div className="pulse-dot" style={{ width: '10px', height: '10px', marginBottom: '10px' }}></div>
          <div>Loading benchmark scorecards and confusion matrices...</div>
        </div>
      ) : data ? (
        <>
          {/* TAB 1: Demand Forecasting */}
          {activeTab === 'forecasting' && (
            <div>
              <div className="glass-panel" style={{ padding: '20px', marginBottom: '22px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px' }}>
                  <div>
                    <div style={{ fontSize: '0.94rem', fontWeight: 700, color: '#F8FAFC' }}>
                      Demand Forecasting Algorithm Benchmark
                    </div>
                    <div style={{ fontSize: '0.74rem', color: '#94A3B8' }}>
                      Chronological test split: 165 consecutive days across all 150 SKUs
                    </div>
                  </div>
                  <span className="pill-badge pill-success">CHAMPION: XGBOOST</span>
                </div>

                <div className="data-table-container">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Algorithm</th>
                        <th>WAPE (%)</th>
                        <th>MAE (Units)</th>
                        <th>RMSE</th>
                        <th>R²</th>
                        <th>Validation Result</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.forecasting.map((row, i) => {
                        const isChamp = row.model_name.includes('XGBoost');
                        return (
                          <tr key={i} style={isChamp ? { background: 'rgba(14, 165, 233, 0.08)' } : {}}>
                            <td style={{ fontWeight: isChamp ? 700 : 500, color: isChamp ? '#38BDF8' : '#F1F5F9' }}>
                              {row.model_name}
                            </td>
                            <td style={{ fontWeight: 700 }}>{row.wape}%</td>
                            <td>{row.mae}</td>
                            <td>{row.rmse}</td>
                            <td>{row.r2}</td>
                            <td>
                              {isChamp ? (
                                <span className="pill-badge pill-success">CHAMPION MODEL</span>
                              ) : (
                                <span className="pill-badge pill-neutral">BENCHMARK</span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Technical Insight Box */}
              <div className="alert-box alert-info">
                <div style={{ fontWeight: 700, fontSize: '0.86rem', color: '#38BDF8', marginBottom: '4px' }}>
                  Why WAPE (Weighted Absolute Percentage Error)?
                </div>
                <div style={{ fontSize: '0.78rem', color: '#94A3B8', lineHeight: '1.45' }}>
                  Standard MAPE divides by actual demand, leading to infinite or undefined percentages during frequent zero-sales days in intermittent medicine demand. WAPE aggregates absolute errors across the entire period and divides by total volume, providing a stable, mathematically rigorous benchmark.
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Expiry Risk */}
          {activeTab === 'expiry' && (
            <div>
              <div className="glass-panel" style={{ padding: '20px', marginBottom: '22px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px' }}>
                  <div>
                    <div style={{ fontSize: '0.94rem', fontWeight: 700, color: '#F8FAFC' }}>
                      Expiry Intelligence: Dual-Task Validation Suite
                    </div>
                    <div style={{ fontSize: '0.74rem', color: '#94A3B8' }}>
                      Task A (Risk Classification) + Task B (Unsold Volume Regression)
                    </div>
                  </div>
                  <span className="pill-badge pill-success">RECALL: 94.44%</span>
                </div>

                <div className="data-table-container" style={{ marginBottom: '20px' }}>
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Task / Algorithm</th>
                        <th>Recall (%)</th>
                        <th>Precision (%)</th>
                        <th>Accuracy (%)</th>
                        <th>MAE (Units)</th>
                        <th>ROC-AUC</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.expiry.map((row, i) => (
                        <tr key={i}>
                          <td style={{ fontWeight: 600, color: '#F1F5F9' }}>{row.model_name}</td>
                          <td style={{ fontWeight: 700, color: '#34D399' }}>{row.recall ? `${row.recall}%` : 'N/A'}</td>
                          <td>{row.precision ? `${row.precision}%` : 'N/A'}</td>
                          <td>{row.accuracy ? `${row.accuracy}%` : 'N/A'}</td>
                          <td>{row.mae || 'N/A'}</td>
                          <td>{row.roc_auc || 'N/A'}</td>
                          <td><span className="pill-badge pill-success">DEPLOYED</span></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Confusion Matrix Visualization */}
                <div style={{ background: '#0F172A', border: '1px solid var(--border-subtle)', borderRadius: '8px', padding: '16px' }}>
                  <div style={{ fontSize: '0.84rem', fontWeight: 700, color: '#F8FAFC', marginBottom: '10px' }}>
                    Confusion Matrix: Expiry Classifier (Out-of-Sample Holdout Batches)
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '8px', maxWidth: '420px', textAlign: 'center' }}>
                    <div style={{ background: 'rgba(52, 211, 153, 0.1)', border: '1px solid rgba(52, 211, 153, 0.3)', padding: '12px', borderRadius: '6px' }}>
                      <div style={{ fontSize: '1.2rem', fontWeight: 800, color: '#34D399' }}>200</div>
                      <div style={{ fontSize: '0.7rem', color: '#94A3B8' }}>True Negative (Safe Batches)</div>
                    </div>
                    <div style={{ background: 'rgba(251, 191, 36, 0.1)', border: '1px solid rgba(251, 191, 36, 0.3)', padding: '12px', borderRadius: '6px' }}>
                      <div style={{ fontSize: '1.2rem', fontWeight: 800, color: '#FBBF24' }}>4</div>
                      <div style={{ fontSize: '0.7rem', color: '#94A3B8' }}>False Positive (False Alarms)</div>
                    </div>
                    <div style={{ background: 'rgba(248, 113, 113, 0.1)', border: '1px solid rgba(248, 113, 113, 0.3)', padding: '12px', borderRadius: '6px' }}>
                      <div style={{ fontSize: '1.2rem', fontWeight: 800, color: '#F87171' }}>2</div>
                      <div style={{ fontSize: '0.7rem', color: '#94A3B8' }}>False Negative (Missed Expiry)</div>
                    </div>
                    <div style={{ background: 'rgba(56, 189, 248, 0.1)', border: '1px solid rgba(56, 189, 248, 0.3)', padding: '12px', borderRadius: '6px' }}>
                      <div style={{ fontSize: '1.2rem', fontWeight: 800, color: '#38BDF8' }}>34</div>
                      <div style={{ fontSize: '0.7rem', color: '#94A3B8' }}>True Positive (Detected Expired)</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Stockout Prediction */}
          {activeTab === 'stockout' && (
            <div>
              <div className="glass-panel" style={{ padding: '20px', marginBottom: '22px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px' }}>
                  <div>
                    <div style={{ fontSize: '0.94rem', fontWeight: 700, color: '#F8FAFC' }}>
                      Stockout Classifier Performance (7-Day Vendor Lead-Time Horizon)
                    </div>
                    <div style={{ fontSize: '0.74rem', color: '#94A3B8' }}>
                      Random Forest Classifier evaluated on out-of-sample holdout test partition
                    </div>
                  </div>
                  <span className="pill-badge pill-success">RECALL: 81.48%</span>
                </div>

                <div className="data-table-container" style={{ marginBottom: '20px' }}>
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Algorithm</th>
                        <th>Recall (%)</th>
                        <th>Precision (%)</th>
                        <th>F1-Score (%)</th>
                        <th>ROC-AUC</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.stockout.map((row, i) => (
                        <tr key={i}>
                          <td style={{ fontWeight: 600, color: '#F1F5F9' }}>{row.model_name}</td>
                          <td style={{ fontWeight: 700, color: '#34D399' }}>{row.recall ? `${row.recall}%` : 'N/A'}</td>
                          <td>{row.precision ? `${row.precision}%` : 'N/A'}</td>
                          <td>{row.f1_score ? `${row.f1_score}%` : 'N/A'}</td>
                          <td>{row.roc_auc || 'N/A'}</td>
                          <td><span className="pill-badge pill-success">DEPLOYED</span></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Confusion Matrix Visualization */}
                <div style={{ background: '#0F172A', border: '1px solid var(--border-subtle)', borderRadius: '8px', padding: '16px' }}>
                  <div style={{ fontSize: '0.84rem', fontWeight: 700, color: '#F8FAFC', marginBottom: '10px' }}>
                    Confusion Matrix: Stockout Classifier (Holdout Test Replenishment Events)
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '8px', maxWidth: '420px', textAlign: 'center' }}>
                    <div style={{ background: 'rgba(52, 211, 153, 0.1)', border: '1px solid rgba(52, 211, 153, 0.3)', padding: '12px', borderRadius: '6px' }}>
                      <div style={{ fontSize: '1.2rem', fontWeight: 800, color: '#34D399' }}>234</div>
                      <div style={{ fontSize: '0.7rem', color: '#94A3B8' }}>True Negative (Sufficient Stock)</div>
                    </div>
                    <div style={{ background: 'rgba(251, 191, 36, 0.1)', border: '1px solid rgba(251, 191, 36, 0.3)', padding: '12px', borderRadius: '6px' }}>
                      <div style={{ fontSize: '1.2rem', fontWeight: 800, color: '#FBBF24' }}>12</div>
                      <div style={{ fontSize: '0.7rem', color: '#94A3B8' }}>False Positive (Precautionary PO)</div>
                    </div>
                    <div style={{ background: 'rgba(248, 113, 113, 0.1)', border: '1px solid rgba(248, 113, 113, 0.3)', padding: '12px', borderRadius: '6px' }}>
                      <div style={{ fontSize: '1.2rem', fontWeight: 800, color: '#F87171' }}>10</div>
                      <div style={{ fontSize: '0.7rem', color: '#94A3B8' }}>False Negative (Unpredicted Exhaustion)</div>
                    </div>
                    <div style={{ background: 'rgba(56, 189, 248, 0.1)', border: '1px solid rgba(56, 189, 248, 0.3)', padding: '12px', borderRadius: '6px' }}>
                      <div style={{ fontSize: '1.2rem', fontWeight: 800, color: '#38BDF8' }}>44</div>
                      <div style={{ fontSize: '0.7rem', color: '#94A3B8' }}>True Positive (Detected Threats)</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: Sales Clustering */}
          {activeTab === 'clustering' && (
            <div>
              <div className="glass-panel" style={{ padding: '20px', marginBottom: '22px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px' }}>
                  <div>
                    <div style={{ fontSize: '0.94rem', fontWeight: 700, color: '#F8FAFC' }}>
                      Unsupervised Clustering Validation Metrics
                    </div>
                    <div style={{ fontSize: '0.74rem', color: '#94A3B8' }}>
                      K-Means model evaluated across candidate k values (2 through 6)
                    </div>
                  </div>
                  <span className="pill-badge pill-success">OPTIMAL k = 3</span>
                </div>

                <div className="data-table-container">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Cluster Configuration</th>
                        <th>Silhouette Score</th>
                        <th>Davies-Bouldin Index</th>
                        <th>Calinski-Harabasz</th>
                        <th>Validation Decision</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>k = 2 Clusters</td>
                        <td>0.3812</td>
                        <td>1.042</td>
                        <td>94.2</td>
                        <td><span className="pill-badge pill-neutral">UNDER-FITTED</span></td>
                      </tr>
                      <tr style={{ background: 'rgba(14, 165, 233, 0.08)' }}>
                        <td style={{ fontWeight: 700, color: '#38BDF8' }}>k = 3 Clusters (Production)</td>
                        <td style={{ fontWeight: 700, color: '#34D399' }}>0.4201</td>
                        <td style={{ fontWeight: 700 }}>0.884</td>
                        <td style={{ fontWeight: 700 }}>128.6</td>
                        <td><span className="pill-badge pill-success">CHAMPION PARTITION</span></td>
                      </tr>
                      <tr>
                        <td>k = 4 Clusters</td>
                        <td>0.3745</td>
                        <td>0.991</td>
                        <td>112.4</td>
                        <td><span className="pill-badge pill-neutral">OVER-SEGMENTED</span></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Mathematical Formulations Footer */}
          <div className="glass-panel" style={{ padding: '20px' }}>
            <div style={{ fontSize: '0.88rem', fontWeight: 700, color: '#F8FAFC', marginBottom: '12px' }}>
              Mathematical Metric Definitions
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '14px' }}>
              {data.formulas.map((f, i) => (
                <div key={i} style={{ background: '#0F172A', padding: '14px', borderRadius: '8px', border: '1px solid var(--border-subtle)' }}>
                  <div style={{ fontSize: '0.8rem', fontWeight: 700, color: '#38BDF8', marginBottom: '4px' }}>{f.name}</div>
                  <div style={{ fontFamily: 'monospace', fontSize: '0.72rem', color: '#F1F5F9', background: 'rgba(0,0,0,0.3)', padding: '6px', borderRadius: '4px', marginBottom: '6px' }}>
                    {f.formula}
                  </div>
                  <div style={{ fontSize: '0.7rem', color: '#94A3B8' }}>{f.purpose}</div>
                </div>
              ))}
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}
