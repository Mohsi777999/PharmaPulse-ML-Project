import React, { useState, useEffect } from 'react';
import HeroBanner from '../components/HeroBanner';
import KpiCard from '../components/KpiCard';
import { api } from '../services/api';
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer,
  BarChart, Bar, PieChart, Pie, Cell, Legend
} from 'recharts';
import { AlertCircle, TrendingUp, TrendingDown, Package, ShieldCheck } from 'lucide-react';

export default function OverviewView() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadOverview();
  }, []);

  const loadOverview = async () => {
    try {
      setLoading(true);
      const res = await api.getOverview();
      setData(res);
    } catch (err) {
      console.error('Failed to load overview data:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading || !data) {
    return (
      <div style={{ padding: '40px', textAlign: 'center', color: '#94A3B8' }}>
        <div className="pulse-dot" style={{ width: '12px', height: '12px', marginBottom: '12px' }}></div>
        <div>Loading Executive Command Center...</div>
      </div>
    );
  }

  const { kpis, monthly_velocity, categories, critical_expiry_batches, urgent_stockouts, top_growing, top_declining } = data;

  const COLORS = ['#38BDF8', '#34D399', '#818CF8', '#FBBF24', '#F87171', '#A78BFA'];

  return (
    <div>
      <HeroBanner
        tag="OPERATIONS INTELLIGENCE • BRANCH 1 REGIONAL HUB"
        title="PharmaPulse — Executive Operations Overview"
        subtitle="Machine-learning decision support platform delivering multi-horizon demand forecasting, batch expiry exposure quantification, lead-time stockout early warnings, and SKU behavioral segmentation."
      />

      {/* 5 KPI Metric Row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '14px', marginBottom: '24px' }}>
        <KpiCard
          title="Active Formulary"
          value={`${kpis.active_medicines} SKUs`}
          subtext="Distributed across 6 categories"
          icon="💊"
          badge="100% Active"
          badgeType="neutral"
        />
        <KpiCard
          title="3-Year Gross Revenue"
          value={`Rs. ${kpis.gross_revenue_m}M`}
          subtext={`Gross margin: ${kpis.gross_margin_pct}%`}
          icon="💰"
          badge="Healthy"
          badgeType="success"
        />
        <KpiCard
          title="Dispensed Volume"
          value={kpis.units_sold.toLocaleString()}
          subtext={`Fulfillment rate: ${kpis.fulfillment_rate_pct}%`}
          icon="📦"
          badge="96.1% Met"
          badgeType="success"
        />
        <KpiCard
          title="Expired Batches"
          value={kpis.expired_batches}
          subtext={`${kpis.expired_units.toLocaleString()} units written off`}
          icon="⚠️"
          badge="0.32% Loss"
          badgeType="critical"
        />
        <KpiCard
          title="Stockout Incidents"
          value={`${kpis.stockout_pct}%`}
          subtext={`${kpis.stockout_days.toLocaleString()} medicine-days recorded`}
          icon="⚡"
          badge="3.15% Rate"
          badgeType="warning"
        />
      </div>

      {/* Dual Charts Row: Dispensing Velocity & Therapeutic Categories */}
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '18px', marginBottom: '24px' }}>
        {/* Dispensing Velocity Trend */}
        <div className="glass-panel" style={{ padding: '20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
            <div>
              <div style={{ fontSize: '0.92rem', fontWeight: 700, color: '#F8FAFC' }}>
                Monthly Dispensing Velocity Trajectory
              </div>
              <div style={{ fontSize: '0.74rem', color: '#94A3B8' }}>
                36-Month aggregate dispensing units and gross revenue in PKR
              </div>
            </div>
            <span className="pill-badge pill-cyan">36 MONTHS DATA</span>
          </div>

          <div style={{ height: '240px', width: '100%' }}>
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthly_velocity}>
                <defs>
                  <linearGradient id="colorUnits" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#38BDF8" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#38BDF8" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="month" stroke="#64748B" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748B" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#111827', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '8px', fontSize: '12px' }}
                  labelStyle={{ color: '#F1F5F9', fontWeight: 600 }}
                />
                <Area type="monotone" dataKey="units" stroke="#38BDF8" strokeWidth={2} fillOpacity={1} fill="url(#colorUnits)" name="Dispensed Units" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Therapeutic Categories Breakdown */}
        <div className="glass-panel" style={{ padding: '20px' }}>
          <div style={{ fontSize: '0.92rem', fontWeight: 700, color: '#F8FAFC', marginBottom: '4px' }}>
            Therapeutic Category Breakdown
          </div>
          <div style={{ fontSize: '0.74rem', color: '#94A3B8', marginBottom: '14px' }}>
            Dispensed volume distribution
          </div>

          <div style={{ height: '220px', width: '100%' }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categories}
                  dataKey="units_sold"
                  nameKey="category_name"
                  cx="50%"
                  cy="50%"
                  outerRadius={75}
                  innerRadius={45}
                  paddingAngle={3}
                >
                  {categories.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#111827', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '8px', fontSize: '12px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Critical AI Alerts Row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '18px', marginBottom: '24px' }}>
        {/* Critical Batches Approaching Expiry */}
        <div className="glass-panel" style={{ padding: '20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <AlertCircle size={18} color="#F87171" />
              <div style={{ fontSize: '0.9rem', fontWeight: 700, color: '#F8FAFC' }}>
                Critical Batches Approaching Expiry
              </div>
            </div>
            <span className="pill-badge pill-critical">ACTION REQUIRED</span>
          </div>
          <div style={{ fontSize: '0.76rem', color: '#94A3B8', marginBottom: '14px' }}>
            Batches under 30 days to expiry with projected unsold units.
          </div>

          <div className="data-table-container">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Batch ID</th>
                  <th>Medicine</th>
                  <th>Days Left</th>
                  <th>Units</th>
                  <th>Exposure (PKR)</th>
                </tr>
              </thead>
              <tbody>
                {critical_expiry_batches && critical_expiry_batches.slice(0, 5).map((b, i) => (
                  <tr key={i}>
                    <td style={{ fontFamily: 'monospace', color: '#38BDF8' }}>{b.batch_id}</td>
                    <td>{b.medicine_name}</td>
                    <td><span className="pill-badge pill-critical">{b.days_to_expiry}d</span></td>
                    <td>{b.remaining_batch_quantity}</td>
                    <td style={{ color: '#F87171', fontWeight: 600 }}>Rs. {Number(b.financial_exposure).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Urgent Stockout Threats */}
        <div className="glass-panel" style={{ padding: '20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <ShieldCheck size={18} color="#FBBF24" />
              <div style={{ fontSize: '0.9rem', fontWeight: 700, color: '#F8FAFC' }}>
                Stockout Replenishment Alerts
              </div>
            </div>
            <span className="pill-badge pill-warning">EARLY WARNING</span>
          </div>
          <div style={{ fontSize: '0.76rem', color: '#94A3B8', marginBottom: '14px' }}>
            Medicines with inventory exhaustion risk during vendor lead time.
          </div>

          <div className="data-table-container">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Medicine</th>
                  <th>Supply Days</th>
                  <th>Lead Time</th>
                  <th>Supplier</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {urgent_stockouts && urgent_stockouts.slice(0, 5).map((s, i) => (
                  <tr key={i}>
                    <td>{s.medicine_name}</td>
                    <td><span className="pill-badge pill-warning">{s.days_of_supply}d</span></td>
                    <td>{s.expected_lead_time_days}d</td>
                    <td style={{ color: '#94A3B8' }}>{s.supplier_id}</td>
                    <td><span className="pill-badge pill-critical">EXPEDITE PO</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Growth & Decline Dynamics */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '18px' }}>
        <div className="glass-panel" style={{ padding: '18px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
            <TrendingUp size={16} color="#34D399" />
            <div style={{ fontSize: '0.86rem', fontWeight: 700, color: '#F8FAFC' }}>
              Top Demand Velocity Gainers (Last 30 Days)
            </div>
          </div>
          <div className="data-table-container">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Medicine</th>
                  <th>Growth %</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {top_growing && top_growing.map((m, i) => (
                  <tr key={i}>
                    <td>{m.medicine_name}</td>
                    <td style={{ color: '#34D399', fontWeight: 700 }}>+{m.growth_pct}%</td>
                    <td><span className="pill-badge pill-success">EXPANDING</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="glass-panel" style={{ padding: '18px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
            <TrendingDown size={16} color="#F87171" />
            <div style={{ fontSize: '0.86rem', fontWeight: 700, color: '#F8FAFC' }}>
              Demand Contraction Watchlist (Last 30 Days)
            </div>
          </div>
          <div className="data-table-container">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Medicine</th>
                  <th>Decline %</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {top_declining && top_declining.map((m, i) => (
                  <tr key={i}>
                    <td>{m.medicine_name}</td>
                    <td style={{ color: '#F87171', fontWeight: 700 }}>{m.decline_pct}%</td>
                    <td><span className="pill-badge pill-neutral">COOLING</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
