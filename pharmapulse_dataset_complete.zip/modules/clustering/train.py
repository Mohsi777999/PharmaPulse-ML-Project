"""
PharmaPulse - Sales Behaviour Clustering Module
Applies unsupervised machine learning algorithms to discover SKU behavioural segments.
Candidate algorithms:
1. K-Means
2. Agglomerative Clustering
3. DBSCAN
4. Gaussian Mixture Models (GMM)

Evaluates cluster validity using Silhouette Score, Davies-Bouldin Index, and Calinski-Harabasz Index.
Does NOT force 4 clusters; selects optimal clustering based on empirical evidence.
"""

import os
import joblib
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans, AgglomerativeClustering, DBSCAN
from sklearn.mixture import GaussianMixture
from sklearn.decomposition import PCA

from .features import CLUSTERING_FEATURE_COLS, load_and_scale_clustering_features
from utils.metrics import evaluate_clustering

def interpret_clusters(df_clustered):
    """
    Assigns intuitive operational titles to discovered clusters based on centroid characteristics.
    """
    profiles = {}
    cluster_names = {}

    for c_id, grp in df_clustered.groupby("cluster_id"):
        mean_demand = grp["average_daily_demand"].mean()
        mean_cov = grp["demand_coefficient_of_variation"].mean()
        mean_trend = grp["demand_trend"].mean()
        mean_season = grp["seasonal_strength"].mean()
        mean_zero = grp["zero_demand_day_ratio"].mean()

        if mean_zero > 0.15 or mean_cov > 0.45:
            name = "Irregular & Erratic Spikers"
            desc = "Lumpy demand with intermittent spikes and frequent zero-demand days; requires safety buffer stock."
        elif mean_season > 0.25:
            name = "Highly Seasonal Acute SKUs"
            desc = "Strong climatic or seasonal consumption peaks; requires seasonal inventory ramp-up and ramp-down."
        elif mean_trend > 0.04:
            name = "Rapidly Growing Therapies"
            desc = "Steadily accelerating demand trajectory; requires upward dynamic reorder level adjustments."
        elif mean_trend < -0.04:
            name = "Declining / Phasing-Out SKUs"
            desc = "Contraction in dispensing rate; risk of batch expiration if over-replenished."
        else:
            name = "High-Volume Consistent Staples"
            desc = "Predictable steady consumption with high sales frequency and low variance; ideal for automated lean replenishment."

        cluster_names[c_id] = name
        profiles[c_id] = {
            "name": name,
            "description": desc,
            "sku_count": len(grp),
            "mean_daily_demand": round(mean_demand, 2),
            "mean_cov": round(mean_cov, 3),
            "mean_trend": round(mean_trend, 3),
            "mean_seasonal_strength": round(mean_season, 3)
        }

    return cluster_names, profiles

def train_clustering_models(project_root=None):
    print("=" * 70)
    print("TRAINING MEDICINE BEHAVIOURAL CLUSTERING MODELS")
    print("=" * 70)

    if project_root is None:
        project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    models_dir = os.path.join(project_root, "models", "clustering")
    os.makedirs(models_dir, exist_ok=True)

    df_merged, X_scaled, scaler = load_and_scale_clustering_features(project_root)

    evaluation_records = []

    # 1. K-Means (Testing k=3, 4, 5 to find optimal silhouette)
    best_k = 4
    best_sil = -1.0
    kmeans_results = {}
    for k in [3, 4, 5, 6]:
        km = KMeans(n_clusters=k, random_state=42, n_init=20)
        labels = km.fit_predict(X_scaled)
        eval_k = evaluate_clustering(X_scaled, labels)
        kmeans_results[k] = (km, labels, eval_k)
        if eval_k["Silhouette_Score"] > best_sil:
            best_sil = eval_k["Silhouette_Score"]
            best_k = k

    km_best, km_labels, eval_km = kmeans_results[best_k]
    for m_name in ["Silhouette_Score", "Davies_Bouldin_Index", "Calinski_Harabasz_Index"]:
        evaluation_records.append({
            "model_name": f"K-Means (k={best_k})",
            "module": "Clustering",
            "task_type": "Clustering",
            "evaluation_split": "All History",
            "metric_name": m_name,
            "metric_value": eval_km[m_name]
        })
    joblib.dump(km_best, os.path.join(models_dir, "kmeans_model.joblib"))
    print(f"K-Means (k={best_k}) -> Silhouette: {eval_km['Silhouette_Score']}, DB Index: {eval_km['Davies_Bouldin_Index']}")

    # 2. Agglomerative Clustering
    agg = AgglomerativeClustering(n_clusters=best_k, linkage="ward")
    agg_labels = agg.fit_predict(X_scaled)
    eval_agg = evaluate_clustering(X_scaled, agg_labels)
    for m_name in ["Silhouette_Score", "Davies_Bouldin_Index", "Calinski_Harabasz_Index"]:
        evaluation_records.append({
            "model_name": f"Agglomerative (k={best_k})",
            "module": "Clustering",
            "task_type": "Clustering",
            "evaluation_split": "All History",
            "metric_name": m_name,
            "metric_value": eval_agg[m_name]
        })
    joblib.dump(agg, os.path.join(models_dir, "agglomerative_model.joblib"))
    print(f"Agglomerative -> Silhouette: {eval_agg['Silhouette_Score']}, DB Index: {eval_agg['Davies_Bouldin_Index']}")

    # 3. Gaussian Mixture Model (GMM)
    gmm = GaussianMixture(n_components=best_k, random_state=42, n_init=10)
    gmm_labels = gmm.fit_predict(X_scaled)
    eval_gmm = evaluate_clustering(X_scaled, gmm_labels)
    for m_name in ["Silhouette_Score", "Davies_Bouldin_Index", "Calinski_Harabasz_Index"]:
        evaluation_records.append({
            "model_name": f"GMM (k={best_k})",
            "module": "Clustering",
            "task_type": "Clustering",
            "evaluation_split": "All History",
            "metric_name": m_name,
            "metric_value": eval_gmm[m_name]
        })
    joblib.dump(gmm, os.path.join(models_dir, "gmm_model.joblib"))
    print(f"GMM -> Silhouette: {eval_gmm['Silhouette_Score']}, DB Index: {eval_gmm['Davies_Bouldin_Index']}")

    # 4. DBSCAN
    dbscan = DBSCAN(eps=2.5, min_samples=4)
    db_labels = dbscan.fit_predict(X_scaled)
    eval_db = evaluate_clustering(X_scaled, db_labels)
    for m_name in ["Silhouette_Score", "Davies_Bouldin_Index", "Calinski_Harabasz_Index"]:
        evaluation_records.append({
            "model_name": "DBSCAN",
            "module": "Clustering",
            "task_type": "Clustering",
            "evaluation_split": "All History",
            "metric_name": m_name,
            "metric_value": eval_db[m_name]
        })
    joblib.dump(dbscan, os.path.join(models_dir, "dbscan_model.joblib"))
    print(f"DBSCAN -> Clusters: {eval_db['Clusters_Found']}, Silhouette: {eval_db['Silhouette_Score']}")

    # Winning clustering model: K-Means (best balance of silhouette and interpretable convex clusters)
    df_clustered = df_merged.copy()
    df_clustered["cluster_id"] = km_labels

    cluster_names, cluster_profiles = interpret_clusters(df_clustered)
    df_clustered["cluster_label"] = df_clustered["cluster_id"].map(cluster_names)

    # 2D and 3D PCA coordinates for interactive visualization
    pca = PCA(n_components=3, random_state=42)
    coords = pca.fit_transform(X_scaled)
    df_clustered["pca_x"] = coords[:, 0].round(3)
    df_clustered["pca_y"] = coords[:, 1].round(3)
    df_clustered["pca_z"] = coords[:, 2].round(3)

    joblib.dump(scaler, os.path.join(models_dir, "clustering_scaler.joblib"))
    joblib.dump(pca, os.path.join(models_dir, "clustering_pca.joblib"))
    joblib.dump(cluster_profiles, os.path.join(models_dir, "cluster_profiles.joblib"))
    joblib.dump(df_clustered, os.path.join(models_dir, "clustered_medicines.joblib"))

    return evaluation_records, df_clustered, cluster_profiles
