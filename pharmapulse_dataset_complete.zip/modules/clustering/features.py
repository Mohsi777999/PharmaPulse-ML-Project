"""
PharmaPulse - Clustering Feature Pipeline
Extracts 90-day rolling behavioural demand features at SKU level.
Excludes simulator demand_pattern and metadata to guarantee true unsupervised discovery.
"""

import os
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

CLUSTERING_FEATURE_COLS = [
    "average_daily_demand", "demand_std", "demand_coefficient_of_variation",
    "average_monthly_demand", "total_units_sold", "sales_frequency",
    "zero_demand_day_ratio", "demand_trend", "seasonal_strength",
    "average_daily_sales", "stockout_day_ratio", "unfulfilled_demand_ratio"
]

def load_and_scale_clustering_features(project_root=None):
    """
    Loads clustering features from data/processed/clustering_features.csv,
    scales numerical columns using StandardScaler, and returns scaled array + dataframe.
    """
    if project_root is None:
        project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    p_data = os.path.join(project_root, "data", "processed", "clustering_features.csv")
    df = pd.read_csv(p_data)

    # Medicine metadata for visualization
    p_meds = os.path.join(project_root, "data", "raw", "medicines.csv")
    df_meds = pd.read_csv(p_meds)[["medicine_id", "medicine_name", "category_id"]]

    df_merged = df.merge(df_meds, on="medicine_id", how="left")

    X_raw = df_merged[CLUSTERING_FEATURE_COLS].values
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_raw)

    return df_merged, X_scaled, scaler
