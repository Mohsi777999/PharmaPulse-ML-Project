"""
PharmaPulse - Integrated Intelligence Layer
Combines predictions and historical signals across Demand Forecasting, Expiry Risk,
Stockout Prediction, and Sales Clustering into actionable pharmacy-level decision support alerts.
"""

import os
import joblib
import numpy as np
import pandas as pd

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
RAW_DIR = os.path.join(PROJECT_ROOT, "data", "raw")
PROCESSED_DIR = os.path.join(PROJECT_ROOT, "data", "processed")
MODELS_DIR = os.path.join(PROJECT_ROOT, "models")

def get_pharmacy_intelligence_summary():
    """
    Synthesizes cross-module intelligence for the active pharmacy branch:
    1. Demand trajectory anomalies and growth leaders
    2. Critical batch expiry risks with PKR financial exposure
    3. Urgent stockout warnings and replenishment vulnerabilities
    4. SKU behavioural segment recommendations
    """
    df_meds = pd.read_csv(os.path.join(RAW_DIR, "medicines.csv"))
    df_inv = pd.read_csv(os.path.join(RAW_DIR, "daily_inventory.csv"))
    df_sales = pd.read_csv(os.path.join(RAW_DIR, "daily_demand_sales.csv"))
    df_pos = pd.read_csv(os.path.join(RAW_DIR, "purchase_orders.csv"))
    df_snapshots = pd.read_csv(os.path.join(PROCESSED_DIR, "expiry_prediction_snapshots.csv"))
    df_stockout = pd.read_csv(os.path.join(PROCESSED_DIR, "stockout_prediction_data.csv"))
    df_clustering = pd.read_csv(os.path.join(PROCESSED_DIR, "clustering_features.csv"))

    med_dict = df_meds.set_index("medicine_id").to_dict(orient="index")

    # 1. Demand Intelligence
    # Recent trend: compare last 30d demand vs prior 30d demand
    recent_dates = df_sales["date"].unique()
    last_30_dates = set(recent_dates[-30:])
    prev_30_dates = set(recent_dates[-60:-30])

    sales_last_30 = df_sales[df_sales["date"].isin(last_30_dates)].groupby("medicine_id")["actual_demand"].sum()
    sales_prev_30 = df_sales[df_sales["date"].isin(prev_30_dates)].groupby("medicine_id")["actual_demand"].sum()
    growth_ratio = (sales_last_30 - sales_prev_30) / np.maximum(sales_prev_30, 1.0)

    top_growing = growth_ratio.nlargest(5).reset_index()
    top_growing.columns = ["medicine_id", "growth_ratio"]
    top_growing["medicine_name"] = top_growing["medicine_id"].map(lambda m: med_dict[m]["medicine_name"])
    top_growing["growth_pct"] = (top_growing["growth_ratio"] * 100.0).round(1)

    top_declining = growth_ratio.nsmallest(5).reset_index()
    top_declining.columns = ["medicine_id", "decline_ratio"]
    top_declining["medicine_name"] = top_declining["medicine_id"].map(lambda m: med_dict[m]["medicine_name"])
    top_declining["decline_pct"] = (top_declining["decline_ratio"] * 100.0).round(1)

    # 2. Expiry Intelligence & Financial Exposure
    # Filter to active batches at near-expiry snapshots (<= 30 days)
    recent_snaps = df_snapshots[df_snapshots["days_to_expiry"] <= 30].copy()
    recent_snaps["unit_cost"] = recent_snaps["medicine_id"].map(lambda m: med_dict[m]["unit_cost"])
    recent_snaps["medicine_name"] = recent_snaps["medicine_id"].map(lambda m: med_dict[m]["medicine_name"])
    
    # Financial exposure: estimated unsold units * cost
    est_unsold = recent_snaps["target_unsold_quantity"].fillna(recent_snaps["remaining_batch_quantity"] * 0.25)
    recent_snaps["financial_exposure"] = (est_unsold * recent_snaps["unit_cost"]).round(2)

    critical_batches = recent_snaps[recent_snaps["target_expiry_risk_class"].isin(["High", "Critical"])].sort_values("financial_exposure", ascending=False).head(10)
    total_expiry_exposure = float(critical_batches["financial_exposure"].sum())

    # 3. Stockout Intelligence
    # Recent purchase orders with stockout risk
    recent_pos = df_stockout.tail(50).copy()
    recent_pos["medicine_name"] = recent_pos["medicine_id"].map(lambda m: med_dict[m]["medicine_name"])
    high_risk_stockouts = recent_pos[recent_pos["target_stockout_before_arrival"] == 1.0].head(8)

    # Closing usable stock on final day
    last_date = df_inv["date"].max()
    final_day_inv = df_inv[df_inv["date"] == last_date].copy()
    final_day_inv["medicine_name"] = final_day_inv["medicine_id"].map(lambda m: med_dict[m]["medicine_name"])
    low_coverage_meds = final_day_inv.sort_values("days_of_inventory_remaining").head(8)

    # 4. Behavioral Clustering Profile
    cluster_profiles_path = os.path.join(MODELS_DIR, "clustering", "cluster_profiles.joblib")
    cluster_profiles = joblib.load(cluster_profiles_path) if os.path.exists(cluster_profiles_path) else {}

    return {
        "top_growing_medicines": top_growing.to_dict(orient="records"),
        "top_declining_medicines": top_declining.to_dict(orient="records"),
        "critical_expiry_batches": critical_batches[["batch_id", "medicine_id", "medicine_name", "days_to_expiry", "remaining_batch_quantity", "target_expiry_risk_class", "financial_exposure"]].to_dict(orient="records"),
        "total_critical_exposure_pkr": round(total_expiry_exposure, 2),
        "high_risk_stockouts": high_risk_stockouts[["purchase_order_id", "medicine_id", "medicine_name", "usable_stock_at_order", "supplier_lead_time_days"]].to_dict(orient="records"),
        "low_coverage_inventory": low_coverage_meds[["medicine_id", "medicine_name", "closing_stock", "days_of_inventory_remaining"]].to_dict(orient="records"),
        "cluster_profiles": cluster_profiles
    }
