import os
import sys
import pandas as pd
import numpy as np
from fastapi import APIRouter

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from utils.data_loader import (
    load_medicines, load_categories, load_daily_demand_sales,
    load_daily_inventory, load_dataset_summary, load_validation_report
)
from modules.intelligence.insights import get_pharmacy_intelligence_summary

router = APIRouter(prefix="/api/overview", tags=["Overview"])

@router.get("")
def get_overview_data():
    summary = load_dataset_summary()
    val_report = load_validation_report()
    df_sales = load_daily_demand_sales()
    df_meds = load_medicines()
    df_cats = load_categories()
    insights = get_pharmacy_intelligence_summary()

    # 1. KPIs
    rev_pkr = float(summary.get("total_gross_revenue_pkr", 301448140))
    profit_pkr = float(summary.get("gross_profit_pkr", 92822615))
    kpis = {
        "active_medicines": int(summary.get("total_medicines", 150)),
        "gross_revenue_pkr": rev_pkr,
        "gross_revenue_m": round(rev_pkr / 1e6, 2),
        "gross_profit_pkr": profit_pkr,
        "gross_profit_m": round(profit_pkr / 1e6, 2),
        "gross_margin_pct": round(profit_pkr / max(rev_pkr, 1.0) * 100.0, 1),
        "units_sold": int(summary.get("total_units_sold", 3368640)),
        "fulfillment_rate_pct": float(summary.get("fulfillment_rate", 96.05)),
        "batches_tracked": int(summary.get("total_batches_tracked", 9567)),
        "expired_batches": int(summary.get("expired_batches", 31)),
        "expired_units": int(summary.get("expired_units", 5538)),
        "stockout_days": int(summary.get("stockout_medicine_days", 5181)),
        "stockout_pct": float(summary.get("stockout_day_percentage", 3.15)),
        "audit_status": val_report.get("overall_status", "PASS")
    }

    # 2. Monthly dispensing velocity (36 months)
    df_sales["month_period"] = pd.to_datetime(df_sales["date"]).dt.to_period("M").astype(str)
    monthly = df_sales.groupby("month_period").agg(
        dispensed_units=("actual_demand", "sum"),
        revenue_pkr=("revenue_pkr", "sum") if "revenue_pkr" in df_sales.columns else ("actual_demand", lambda x: np.sum(x) * 89.5)
    ).reset_index()

    monthly_data = []
    for _, row in monthly.iterrows():
        monthly_data.append({
            "month": str(row["month_period"]),
            "units": int(row["dispensed_units"]),
            "revenue_k": round(float(row["revenue_pkr"]) / 1000.0, 1)
        })

    # 3. Category distribution
    cat_dict = df_cats.set_index("category_id")["category_name"].to_dict()
    med_cat_map = df_meds.set_index("medicine_id")["category_id"].to_dict()
    df_sales["category_id"] = df_sales["medicine_id"].map(med_cat_map)
    cat_sales = df_sales.groupby("category_id")["actual_demand"].sum().reset_index()
    cat_sales["category_name"] = cat_sales["category_id"].map(cat_dict)

    cat_counts = df_meds["category_id"].value_counts().to_dict()
    categories_data = []
    for _, row in cat_sales.iterrows():
        cid = row["category_id"]
        cname = row["category_name"] if pd.notna(row["category_name"]) else cid
        categories_data.append({
            "category_id": cid,
            "category_name": cname,
            "sku_count": int(cat_counts.get(cid, 0)),
            "units_sold": int(row["actual_demand"])
        })

    # 4. Critical alerts
    return {
        "kpis": kpis,
        "monthly_velocity": monthly_data,
        "categories": categories_data,
        "critical_expiry_batches": insights.get("critical_expiry_batches", []),
        "urgent_stockouts": insights.get("urgent_stockout_risks", []),
        "top_growing": insights.get("top_growing_medicines", []),
        "top_declining": insights.get("top_declining_medicines", [])
    }
