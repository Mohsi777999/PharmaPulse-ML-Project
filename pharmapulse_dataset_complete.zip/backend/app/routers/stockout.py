import os
import sys
import pandas as pd
import numpy as np
from fastapi import APIRouter, Query

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from utils.data_loader import (
    load_medicines, load_suppliers, load_categories,
    load_stockout_prediction_data, load_purchase_orders, load_model_evaluations
)

router = APIRouter(prefix="/api/stockout", tags=["Stockout Intelligence"])

@router.get("")
def get_stockout_data(
    supplier_id: str = "ALL",
    risk_level: str = "ALL"
):
    df_meds = load_medicines()
    df_sups = load_suppliers()
    df_cats = load_categories()
    df_so = load_stockout_prediction_data()
    df_pos = load_purchase_orders()
    df_evals = load_model_evaluations()

    med_dict = df_meds.set_index("medicine_id").to_dict(orient="index")
    sup_dict = df_sups.set_index("supplier_id").to_dict(orient="index")
    cat_dict = df_cats.set_index("category_id")["category_name"].to_dict()

    df = df_so.copy()
    df["medicine_name"] = df["medicine_id"].map(lambda m: med_dict.get(m, {}).get("medicine_name", m))
    df["category_id"] = df["medicine_id"].map(lambda m: med_dict.get(m, {}).get("category_id", "CAT_01"))
    df["category_name"] = df["category_id"].map(lambda c: cat_dict.get(c, c))
    df["supplier_name"] = df["supplier_id"].map(lambda s: sup_dict.get(s, {}).get("supplier_name", s))

    # Risk Flag
    df["risk_flag"] = df["target_stockout_before_arrival"].apply(
        lambda v: "High Risk" if v == 1.0 else ("Low Risk" if v == 0.0 else "Pending Arrival")
    )

    # Global Unfiltered Metrics
    total_evaluated = len(df)
    high_risk_count = int((df["risk_flag"] == "High Risk").sum())
    stockout_vulnerability_pct = round((high_risk_count / max(total_evaluated, 1)) * 100.0, 1)
    avg_burn_rate = round(float(df["daily_consumption_rate"].mean()), 1) if "daily_consumption_rate" in df.columns else 8.4
    avg_days_of_supply = round(float(df["days_of_supply"].mean()), 1) if "days_of_supply" in df.columns else 12.3

    # Supplier Performance Breakdown
    suppliers_summary = []
    for _, sup in df_sups.iterrows():
        sid = str(sup["supplier_id"])
        sname = str(sup["supplier_name"])
        reliability = float(sup.get("reliability_score", 0.85)) * 100.0
        lead_time = float(sup.get("average_lead_time_days", 5.0))
        
        # Buffer multiplier based on reliability
        buffer_mult = round(1.0 + (100.0 - reliability) / 100.0 * 0.5, 2)
        suppliers_summary.append({
            "supplier_id": sid,
            "supplier_name": sname,
            "reliability_pct": round(reliability, 1),
            "lead_time_days": round(lead_time, 1),
            "buffer_multiplier": buffer_mult,
            "performance_tier": "Tier A (Preferred)" if reliability >= 90 else ("Tier B (Standard)" if reliability >= 80 else "Tier C (Watchlist)")
        })

    # Apply Filters for Stockout Items Table
    filtered_df = df.copy()
    if supplier_id != "ALL":
        filtered_df = filtered_df[filtered_df["supplier_id"] == supplier_id]
    if risk_level != "ALL":
        filtered_df = filtered_df[filtered_df["risk_flag"] == risk_level]

    stockout_items = []
    for _, r in filtered_df.head(150).iterrows():
        stock = int(r.get("current_stock_level", 0))
        burn = float(r.get("daily_consumption_rate", 5.0))
        dos = float(r.get("days_of_supply", 10.0))
        lt = int(r.get("expected_lead_time_days", 5))
        is_high = (r["risk_flag"] == "High Risk")
        
        if is_high:
            action = "Urgent: Expedite In-Transit PO / Place Emergency Buffer"
        elif dos < lt * 1.5:
            action = "Warning: Review Reorder Level & Supplier Lead Time"
        else:
            action = "Stable: Inventory Adequate for Cycle"

        stockout_items.append({
            "medicine_id": str(r["medicine_id"]),
            "medicine_name": str(r["medicine_name"]),
            "category_name": str(r["category_name"]),
            "supplier_name": str(r["supplier_name"]),
            "current_stock": stock,
            "burn_rate": round(burn, 1),
            "days_of_supply": round(dos, 1),
            "lead_time_days": lt,
            "risk_flag": str(r["risk_flag"]),
            "recommended_action": action
        })

    # Active Purchase Orders
    pos_data = []
    if not df_pos.empty:
        pos_display = df_pos.tail(50).copy()
        pos_display["medicine_name"] = pos_display["medicine_id"].map(lambda m: med_dict.get(m, {}).get("medicine_name", m))
        pos_display["supplier_name"] = pos_display["supplier_id"].map(lambda s: sup_dict.get(s, {}).get("supplier_name", s))
        for _, p in pos_display.iterrows():
            pos_data.append({
                "po_id": str(p.get("purchase_order_id", p.get("po_id", "PO_001"))),
                "medicine_name": str(p["medicine_name"]),
                "supplier_name": str(p["supplier_name"]),
                "quantity": int(p.get("ordered_quantity", p.get("order_quantity", 100))),
                "order_date": str(p.get("order_date", "2026-10-01")),
                "expected_delivery": str(p.get("expected_delivery_date", "2026-10-07")),
                "status": str(p.get("purchase_order_status", p.get("status", "Delivered")))
            })

    # ML Benchmarks for Stockout
    so_evals = df_evals[df_evals["module"].str.contains("stockout", case=False, na=False)].to_dict(orient="records")

    return {
        "kpis": {
            "total_monitored_events": total_evaluated,
            "high_risk_threats": high_risk_count,
            "vulnerability_rate_pct": stockout_vulnerability_pct,
            "avg_burn_rate_daily": avg_burn_rate,
            "avg_days_of_supply": avg_days_of_supply,
            "active_suppliers_count": len(df_sups)
        },
        "suppliers": suppliers_summary,
        "items": stockout_items,
        "recent_pos": pos_data,
        "evaluations": so_evals
    }
