import os
import sys
import pandas as pd
import numpy as np
from fastapi import APIRouter, Query

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from utils.data_loader import load_medicines, load_categories, load_expiry_prediction_snapshots, load_model_evaluations

router = APIRouter(prefix="/api/expiry", tags=["Expiry Intelligence"])

@router.get("")
def get_expiry_data(
    category_id: str = "ALL",
    risk_level: str = "ALL",
    max_days: int = 365
):
    df_meds = load_medicines()
    df_cats = load_categories()
    df_snaps = load_expiry_prediction_snapshots()
    df_evals = load_model_evaluations()

    med_dict = df_meds.set_index("medicine_id").to_dict(orient="index")
    cat_dict = df_cats.set_index("category_id")["category_name"].to_dict()

    df = df_snaps.copy()
    df["medicine_name"] = df["medicine_id"].map(lambda m: med_dict.get(m, {}).get("medicine_name", m))
    df["category_id"] = df["medicine_id"].map(lambda m: med_dict.get(m, {}).get("category_id", "CAT_01"))
    df["category_name"] = df["category_id"].map(lambda c: cat_dict.get(c, c))
    df["unit_cost"] = df["medicine_id"].map(lambda m: float(med_dict.get(m, {}).get("unit_cost", 20.0)))
    df["selling_price"] = df["medicine_id"].map(lambda m: float(med_dict.get(m, {}).get("selling_price", 30.0)))

    # Target unsold and exposure calculations
    est_unsold = df["target_unsold_quantity"].fillna(df["remaining_batch_quantity"] * 0.20)
    df["est_unsold"] = est_unsold.clip(lower=0)
    df["financial_exposure"] = (df["est_unsold"] * df["unit_cost"]).round(2)
    df["risk_level"] = df["target_expiry_risk_class"].fillna("Low")

    # Overall Unfiltered KPIs
    total_exposure_pkr = float(df["financial_exposure"].sum())
    high_risk_count = int((df["risk_level"] == "High").sum())
    med_risk_count = int((df["risk_level"] == "Medium").sum())
    low_risk_count = int((df["risk_level"] == "Low").sum())
    avg_days_to_expiry = round(float(df["days_to_expiry"].mean()), 1)
    total_units_at_risk = int(df["est_unsold"].sum())

    # Category Exposure Breakdown
    cat_exp = df.groupby(["category_id", "category_name"])["financial_exposure"].sum().reset_index()
    category_exposure = []
    for _, r in cat_exp.iterrows():
        category_exposure.append({
            "category_id": str(r["category_id"]),
            "category_name": str(r["category_name"]),
            "exposure_pkr": round(float(r["financial_exposure"]), 2),
            "exposure_k": round(float(r["financial_exposure"]) / 1000.0, 1)
        })

    # Risk Distribution Breakdown
    risk_distribution = [
        {"name": "High Risk", "value": high_risk_count, "color": "#F87171"},
        {"name": "Medium Risk", "value": med_risk_count, "color": "#FBBF24"},
        {"name": "Low Risk", "value": low_risk_count, "color": "#34D399"}
    ]

    # Apply Filters for Table List
    filtered_df = df[df["days_to_expiry"] <= max_days].copy()
    if category_id != "ALL":
        filtered_df = filtered_df[filtered_df["category_id"] == category_id]
    if risk_level != "ALL":
        filtered_df = filtered_df[filtered_df["risk_level"] == risk_level]

    # Sort by financial exposure descending
    filtered_df = filtered_df.sort_values(by="financial_exposure", ascending=False)

    batches_list = []
    for _, r in filtered_df.head(150).iterrows():
        days_left = int(r["days_to_expiry"])
        if days_left > 90:
            action = "Tier 1: Supplier Return / Swap (Contract Window)"
        elif days_left >= 30:
            action = "Tier 2: 25% Clearance Markdown / Fast-Track FEFO"
        else:
            action = "Tier 3: Inter-Branch Reallocation / Write-off"

        batches_list.append({
            "batch_id": str(r["batch_id"]),
            "medicine_id": str(r["medicine_id"]),
            "medicine_name": str(r["medicine_name"]),
            "category_name": str(r["category_name"]),
            "days_to_expiry": days_left,
            "current_quantity": int(r["remaining_batch_quantity"]),
            "predicted_unsold": round(float(r["est_unsold"]), 1),
            "financial_exposure": float(r["financial_exposure"]),
            "risk_level": str(r["risk_level"]),
            "recommended_action": action
        })

    # Benchmark metrics for Expiry module
    exp_evals = df_evals[df_evals["module"].str.contains("expiry", case=False, na=False)].to_dict(orient="records")

    return {
        "kpis": {
            "total_capital_at_risk_pkr": total_exposure_pkr,
            "total_capital_at_risk_k": round(total_exposure_pkr / 1000.0, 1),
            "high_risk_batches": high_risk_count,
            "medium_risk_batches": med_risk_count,
            "low_risk_batches": low_risk_count,
            "avg_days_to_expiry": avg_days_to_expiry,
            "total_units_at_risk": total_units_at_risk
        },
        "risk_distribution": risk_distribution,
        "category_exposure": category_exposure,
        "batches": batches_list,
        "evaluations": exp_evals
    }
